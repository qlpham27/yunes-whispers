-- Create the schema for your tables below
CREATE TABLE Base_Stats (
    Name TEXT unique PRIMARY KEY,
    Class TEXT NOT NULL,
    Lv Integer,
    Hp Integer,
    Str Integer,
    Mag Integer,
    Skl Integer,
    Spd Integer,
    Lck Integer,
    Def Integer,
    Res Integer,
    Mov Integer,
    Con Integer,
    Wt Integer
);

CREATE TABLE Grow_Rates(
    Class TEXT NOT NULL,
    Hp Integer ,
    Str Integer,
    Mag Integer,
    Skl Integer,
    Spd Integer,
    Lck Integer,
    Def Integer,
    Res Integer  
);

CREATE TABLE Class_Max(
    Class Text unique Primary key,
    Hp Integer ,
    Str Integer,
    Mag Integer,
    Skl Integer,
    Spd Integer,
    Lck Integer,
    Def Integer,
    Res Integer 
);


