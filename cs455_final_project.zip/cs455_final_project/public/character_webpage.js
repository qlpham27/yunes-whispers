window.onload = function() {
    const params = new URLSearchParams(window.location.search);
    const name = params.get('name');
    const detailsDiv = document.getElementById('characterDetails');

    if (!name) {
        // If no name is provided in the URL, show a not found message
        detailsDiv.innerHTML = '<p>Character name is not provided in the URL.</p>';
    } else {
        // Try to load the character image
        const characterImage = document.getElementById('characterImage');
        characterImage.onerror = function() {
            // If the image fails to load, show a not found message
            detailsDiv.innerHTML = '<p>Character image not found.</p>';
        };
        characterImage.src = `/images/${encodeURIComponent(name)}.png`;
        characterImage.alt = name;

    // Fetch character data and populate the table
    fetch(`/getCharacter?name=${encodeURIComponent(name)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.statusText);
            }
            return response.json();
        })
        .then(character => {
            // Check if the character object has data
            if (!character || Object.keys(character).length === 0) {
                throw new Error('No character data found');
            }

            // Render character details as a table
            const table = document.getElementById('characterDetails');
            table.innerHTML = ''; // Clear any existing content
            const thead = document.createElement('thead');
            const tbody = document.createElement('tbody');
            const headRow = document.createElement('tr');
            const dataRow = document.createElement('tr');

            // Assume character is an object where each key is a column name
            Object.keys(character).forEach(key => {
                const th = document.createElement('th');
                th.textContent = key;
                headRow.appendChild(th);

                const td = document.createElement('td');
                td.textContent = character[key];
                dataRow.appendChild(td);
            });

            thead.appendChild(headRow); //the structure 
            tbody.appendChild(dataRow);
            table.appendChild(thead);
            table.appendChild(tbody);
        })
        .catch(error => {
            console.error('Error loading character details:', error);
        });
}};



