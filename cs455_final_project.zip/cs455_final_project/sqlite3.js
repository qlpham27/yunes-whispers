const express = require('express');
const path = require('path');
const app = express();

// Set up static file directory
app.use(express.static(path.join(__dirname, 'public')));

// JSON parsing middleware
app.use(express.json());

// CORS middleware for cross-origin requests
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'content-type');
    res.header('Access-Control-Allow-Methods', 'DELETE,PUT,POST,GET,OPTIONS');
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    } else {
        next();
    }
});

// Base route for serving the main webpage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'base_webpage.html'));
});

// Route parameters for serving character details
app.get('/character_webpage.html/:name', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'character_webpage.html'));
});

// DB router for handling database operations
app.use('/', require('./router/db_router'));

// Start the server
const PORT = process.env.PORT || 80;
app.listen(PORT, () => {
    console.log(`Server running at http://127.0.0.1:${PORT}`);
});
