-- Create the schema for your tables below
CREATE TABLE Base_Stats (
    Name TEXT unique PRIMARY KEY,
    Class TEXT NOT NULL,
    Lv Integer,
    Hp Integer,
    Str Integer,
    Mag Integer,
    Skl Integer,
    Spd Integer,
    Lck Integer,
    Def Integer,
    Res Integer,
    Mov Integer,
    Con Integer,
    Wt Integer
);

CREATE TABLE Growth_Rates(
    Name TEXT UNIQUE NOT NULL PRIMARY KEY,
    Hp Integer,
    Str Integer,
    Mag Integer,
    Skl Integer,
    Spd Integer,
    Lck Integer,
    Def Integer,
    Res Integer,
	FOREIGN KEY (Name) REFERENCES Base_Stats(Name)
		ON UPDATE CASCADE
        ON DELETE CASCADE	
);

CREATE TABLE Class_Max(
    Class TEXT UNIQUE PRIMARY KEY,
    Hp Integer,
    Str Integer,
    Mag Integer,
    Skl Integer,
    Spd Integer,
    Lck Integer,
    Def Integer,
    Res Integer 
);


