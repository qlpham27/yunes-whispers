const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const router = express.Router();

// Specify the database file location
const dbPath = path.join(__dirname, "../db/FE9.db");
const db = new sqlite3.Database(dbPath);

const dbPath2 = path.join(__dirname, "../db/FE10.db");
const db2 = new sqlite3.Database(dbPath2);

// Retrieve all data from the Base_Stats table
// In summary, this code defines a route that, when receiving a GET request to /getBaseStats,
// queries all data from the Base_Stats table and sends it back to the requester in JSON format.
// If an error occurs during the query, it returns a 500 error response.
router.get("/getBaseStats", (req, res) => {
    db.all("SELECT * FROM Base_Stats", [], (err, rows) => {  // []: This is the parameter array passed to the SQL query.
                                                             // In this case, it is empty because the query does not require any parameters.

        if (err) {  // If err is not null or undefined, it indicates an error occurred during database operations.
            res.status(500).send(err.message);
        } else {
            res.json(rows);  // This line converts the query result 'rows' into JSON format and sends it back to the client.
                             // res.json is a shortcut method provided by Express to send a JSON response.
        }
    });
});

router.get("/getBaseStats2", (req, res) => {
    db2.all("SELECT * FROM Base_Stats", [], (err, rows) => {  // []: This is the parameter array passed to the SQL query.
                                                             // In this case, it is empty because the query does not require any parameters.

        if (err) {  // If err is not null or undefined, it indicates an error occurred during database operations.
            res.status(500).send(err.message);
        } else {
            res.json(rows);  // This line converts the query result 'rows' into JSON format and sends it back to the client.
                             // res.json is a shortcut method provided by Express to send a JSON response.
        }
    });
});


router.get('/getCharacter', (req, res) => {
    const name = req.query.name;
    
    const sql = `
        SELECT *
        FROM Base_Stats
        WHERE Base_Stats.Name = ?
    `;

    db.get(sql, [name], (err, row) => {
        if (err) {
            res.status(500).send('Error querying the database');
        } else {
            res.json(row);
            console.log(row);
        }
    });
});

router.get('/getCharacter2', (req, res) => {
    const name = req.query.name;

    const sql = `
        SELECT *
        FROM Base_Stats
        WHERE Base_Stats.Name = ?
    `;

    db2.get(sql, [name], (err, row) => {
        if (err) {
            res.status(500).send('Error querying the database');
        } else {
            res.json(row);
            console.log(row);
        }
    });
});

router.get('/getCharacter3', (req, res) => {
    const name = req.query.name;
    
    const sql = `
        SELECT *
        FROM Growth_Rates
        WHERE Growth_Rates.Name = ?
    `;

    db.get(sql, [name], (err, row) => {
        if (err) {
            res.status(500).send('Error querying the database');
        } else {
            res.json(row);
            console.log(row);
        }
    });
});

router.get('/getCharacter4', (req, res) => {
    const name = req.query.name;
    
    const sql = `
        SELECT *
        FROM Growth_Rates
        WHERE Growth_Rates.Name = ?
    `;

    db2.get(sql, [name], (err, row) => {
        if (err) {
            res.status(500).send('Error querying the database');
        } else {
            res.json(row);
            console.log(row);
        }
    });
});

router.get('/getCharacterSearch', (req, res) => {
    const name = req.query.name;

    const sql = `
        SELECT *
        FROM Base_Stats
        WHERE Base_Stats.Name LIKE ?
    `;

    // To match any name starting with 'da', we add '%' after the passed parameter
    // This indicates that the SQL query will match any name starting with 'da'
    db.all(sql, [name + '%'], (err, row) => {
        if (err) {
            res.status(500).send('Error querying the database');
        } else {
            // If no matching rows are found, return a 404 status and error message
            if (!row) {
                res.status(404).send({ message: 'Character not found' });
            } else {
                res.json(row);
                console.log(row);
            }
        }
    });
});

router.get('/getCharacterSearch2', (req, res) => {
    const name = req.query.name;

    const sql = `
        SELECT *
        FROM Base_Stats
        WHERE Base_Stats.Name LIKE ?
    `;

    // To match any name starting with 'da', we add '%' after the passed parameter
    // This indicates that the SQL query will match any name starting with 'da'
    db2.all(sql, [name + '%'], (err, row) => {
        if (err) {
            res.status(500).send('Error querying the database');
        } else {
            // If no matching rows are found, return a 404 status and error message
            if (!row) {
                res.status(404).send({ message: 'Character not found' });
            } else {
                res.json(row);
                console.log(row);
            }
        }
    });
});

// Export the router
module.exports = router;
