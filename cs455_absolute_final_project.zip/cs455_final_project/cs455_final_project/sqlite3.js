const express = require('express');
const path = require('path');
const app = express();

// Set up static file directory
app.use(express.static(path.join(__dirname, 'public')));

// JSON parsing middleware
app.use(express.json());

// CORS middleware for cross-origin requests
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'content-type');
    res.header('Access-Control-Allow-Methods', 'DELETE,PUT,POST,GET,OPTIONS');
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    } else {
        next();
    }
});

// Base route for serving the main webpage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route parameters that serve subpages
app.get('/cs455_final_project/public/FE9/base_webpage.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'FE9', 'base_webpage.html'));
});

app.get('/cs455_final_project/public/FE9/character_webpage.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'FE9', 'character_webpage.html'));
});

app.get('/cs455_final_project/public/FE9/search_webpage.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'FE9', 'search_webpage.html'));
});

app.get('/cs455_final_project/public/FE10/base_webpage.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'FE10', 'base_webpage.html'));
});

app.get('/cs455_final_project/public/FE10/character_webpage.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'FE10', 'character_webpage.html'));
});

app.get('/cs455_final_project/public/FE10/search_webpage.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'FE10', 'search_webpage.html'));
});

app.get('/cs455_final_project/public/compare.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'compare.html'));
});

app.get('/cs455_final_project/public/compare2.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'compare2.html'));
});

// DB router for handling database operations
app.use('/', require('./router/db_router'));

// Start the server
const PORT = process.env.PORT || 80;
app.listen(PORT, () => {
    console.log(`Server running at http://127.0.0.1:${PORT}`);
});
