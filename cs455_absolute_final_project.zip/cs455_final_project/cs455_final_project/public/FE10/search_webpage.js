window.onload = function() {
    const params = new URLSearchParams(window.location.search);
    const name = params.get('name');

    if (!name) {
        // If no name is provided in the URL, show a not found message
        document.body.innerHTML = '<p>Character name is not provided in the URL.</p>';
    } else {
        // Fetch character data and populate the table
        fetch(`/getCharacterSearch2?name=${encodeURIComponent(name)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.statusText);
            }
            return response.json();
        })
        .then(characters => {
            // Check if there is any character data
            if (!characters || characters.length === 0) {
                throw new Error('No character data found');
            }

            // Render character details as a table
            const table = document.createElement('table');
            table.id = 'characterDetails';
            document.body.innerHTML = ''; // Clear the body before appending the table
            document.body.appendChild(table); // Append the table to the body

            const thead = document.createElement('thead');
            const tbody = document.createElement('tbody');

            // Create header row based on the keys of the first character object
            const headRow = document.createElement('tr');
            Object.keys(characters[0]).forEach(key => {
                const th = document.createElement('th');
                th.textContent = key;
                headRow.appendChild(th);
            });
            thead.appendChild(headRow);
            table.appendChild(thead);

            // Create a row for each character
            characters.forEach(character => {
                const dataRow = document.createElement('tr');
                Object.values(character).forEach(value => {
                    const td = document.createElement('td');
                    td.textContent = value;
                    dataRow.appendChild(td);
                });
                tbody.appendChild(dataRow);
            });
            table.appendChild(tbody);
        })
        .catch(error => {
            console.error('Error loading character details:', error);
            document.body.innerHTML = '<p>Error loading character details.</p>'; // Show error message
        });
    }
}
