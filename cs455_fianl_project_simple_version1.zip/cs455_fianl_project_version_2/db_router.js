const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const router = express.Router();

// location of database 
const dbPath = path.join(__dirname, "../db/cs455Project.db");
const db = new sqlite3.Database(dbPath);

// get the data from Base_Stats table 
router.get("/getBaseStats", (req, res) => {
    db.all("SELECT * FROM Base_Stats", [], (err, rows) => {
        if (err) {
            res.status(500).send(err.message);
        } else {
            res.json(rows);
        }
    });
});

// search base on the Base_Stats table 
router.get("/search", (req, res) => {
    const query = req.query.query; // search keyword 
    const sql = "SELECT * FROM Base_Stats WHERE Name LIKE ? OR Class LIKE ?";
    db.all(sql, [`%${query}%`, `%${query}%`], (err, rows) => {
        if (err) {
            res.status(500).send(err.message);
        } else {
            res.json(rows);
        }
    });
});

// other router 

module.exports = router;