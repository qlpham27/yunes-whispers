const express = require("express");
const path = require("path");
const multer = require("multer");
const app = express();

// static file server 
app.use(express.static(path.join(__dirname, "public")));

// JSON 
app.use(express.json());


app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "content-type");
    res.header("Access-Control-Allow-Methods", "DELETE,PUT,POST,GET,OPTIONS");
    if (req.method == "OPTIONS") {
        res.sendStatus(200);
    } else {
        next();
    }
});

// router 
app.use("/", require("./router/db_router"));

// root router - provide html website 
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'base_webpage.html'));
});

// listener port 
app.listen(80, () => {
    console.log('Server running at http://127.0.0.1');
});
