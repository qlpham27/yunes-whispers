const axios = require('axios');
const fs = require('fs');

axios.get('https://serenesforest.net/path-of-radiance/characters/base-stats/')
    .then(response => {
        const data = response.data;
        fs.writeFile('\output_table1_0.txt', data, (err) => {
            if (err) {
                console.error('Error writing to file:', err);
            } else {
                console.log('Data saved to file output.txt');
            }
        });
    })
    .catch(error => {
        console.error('Error fetching the data:', error);
    });


fs.readFile('\output_table1_0.txt', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading the file:', err);
        return;
    }


    const lines = data.split('\n');


    const selectedLines = lines.slice(489, 1310); 


    const extractedData = selectedLines.join('\n');


    fs.writeFile('\output_table1_1.txt', extractedData, (err) => {
        if (err) {
            console.error('Error writing to file:', err);
        } else {
            console.log('Extracted data saved to output.txt');
        }
    });
});

fs.readFile('\output_table1_1.txt', 'utf8', (err, data) => {
    if (err) {
        return console.error('Error reading the file:', err);
    }


    const regex = /<tr>(.*?)<\/tr>/gs;
    let result = '';
    let match;


    while ((match = regex.exec(data)) !== null) {

        let rowData = match[1].replace(/<td>/g, '').replace(/<\/td>/g, '|').trim();


        rowData = rowData.replace(/&#8211;/g, 'Null').split(/\s+/).join('');

        if (!rowData.includes('"') && !rowData.includes('<')) {

            result += rowData + '\n';
        }

    }

    
    fs.writeFile('\ formatted_output_table1.txt', result.trim(), (err) => {
        if (err) {
            return console.error('Error writing to file:', err);
        }
        console.log('Formatted data saved to formatted_output.txt');
    });
});
