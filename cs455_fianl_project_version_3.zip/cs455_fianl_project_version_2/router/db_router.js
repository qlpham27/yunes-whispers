const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const router = express.Router();


const dbPath = path.join(__dirname, "../db/cs455Project.db");
const db = new sqlite3.Database(dbPath);


router.get("/getBaseStats", (req, res) => {
    db.all("SELECT * FROM Base_Stats", [], (err, rows) => {  

        if (err) {   
            res.status(500).send(err.message);
        } else {
            res.json(rows);                                
                                                           
        }
    });
});


router.get('/getCharacter', (req, res) => {
    const name = req.query.name;
    //NATURAL JOIN Class_Max
    //NATURAL JOIN Grow_Rates
    
    const sql = `
        SELECT *
        FROM Base_Stats   
        WHERE Base_Stats.Name = ?
    `;

    db.get(sql, [name], (err, row) => {
        if (err) {
            res.status(500).send('Error querying the database');
        } else {
            res.json(row);
            console.log(row);
        }
    });
});

router.get('/search', (req, res) => {
    const query = `%${req.query.query}%`;
    const sql = 'SELECT * FROM Base_Stats WHERE Name LIKE ? OR Class LIKE ?';
    db.all(sql, [query, query], (err, rows) => {
        if (err) {
            res.status(500).send('Error querying the database');
        } else {
            res.json(rows);
        }
    });
});

// Export the router
module.exports = router;