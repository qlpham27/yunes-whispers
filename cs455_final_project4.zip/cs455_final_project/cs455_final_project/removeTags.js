function removeTags(str){
    str.split("") // Split into raw chars
    var ret = "" // Return string
    var between = false // True if < found; false if > found. Removes "<...>" text
    for (let i = 0; i < str.length; i++) {
        if (str[i] == "<") {
            between = true
        }else if (str[i] == ">") {
            between = false
        }else {
            if (between != true && str[i] != "*") {
                ret += str[i]
            }
        }
        }
    return ret
};

module.exports = removeTags;