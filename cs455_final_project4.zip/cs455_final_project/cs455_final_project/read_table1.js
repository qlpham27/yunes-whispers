const axios = require('axios');
const fs = require('fs');
const removeTags = require('./removeTags.js');

// Fetch data from the specified URL using axios
axios.get('https://serenesforest.net/radiant-dawn/characters/growth-rates/')
    .then(response => {
        const data = response.data;
        // Write the fetched data to a file
        fs.writeFile('./output_table1_0.txt', data, (err) => {
            if (err) {
                console.error('Error writing to file:', err);
            } else {
                console.log('Data saved to file output.txt');
            }
        });
    })
    .catch(error => {
        console.error('Error fetching the data:', error);
    });

// Read the file
fs.readFile('./output_table1_0.txt', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading the file:', err);
        return;
    }

    // Split the file content into lines
    const lines = data.split('\n');

    // Select lines from 497 to 1799 (array index starts at 0)
    const selectedLines = lines.slice(483, 1319);

    // Combine the selected lines into a new string
    const extractedData = selectedLines.join('\n');

    // Write the extracted data to a new file
    fs.writeFile('./output_table1_1.txt', extractedData, (err) => {
        if (err) {
            console.error('Error writing to file:', err);
        } else {
            console.log('Extracted data saved to output.txt');
        }
    });
});

// Read the file
fs.readFile('./output_table1_1.txt', 'utf8', (err, data) => {
    if (err) {
        return console.error('Error reading the file:', err);
    }

    // Use regular expressions to match everything within <tr>...</tr> and all <td>...</td>
    const regex = /<tr>(.*?)<\/tr>/gs;
    let result = '';
    let match;

    // Loop to match all lines that fit the criteria
    while ((match = regex.exec(data)) !== null) {
        
        // Remove <td> and </td>, and join the contents with spaces
        let rowData = match[1].replace(/<td>/g, '').replace(/<\/td>/g, '|').trim();

        // Remove any extra fluff
        rowData = removeTags(rowData)
        
        // Replace '&#8211;' with 'Null'
        rowData = rowData.replace(/&#8211;/g, 'Null').split(/\s+/).join('');

        // Add the processed line to the result string
        if (!rowData.includes('"') && !rowData.includes('<')) {
            // If it doesn't contain these characters, add the line to the result string
            result += rowData + '\n';
        }
    }

    // Write the final result to a new file
    fs.writeFile('./formatted_output_table1.txt', result.trim(), (err) => {
        if (err) {
            return console.error('Error writing to file:', err);
        }
        console.log('Formatted data saved to formatted_output.txt');
    });
});
